document.addEventListener('DOMContentLoaded', () => {

    const hash = window.location.hash;

    if (hash) {

        window.scrollTo(0, 0);


        history.replaceState(null, null, ' ');

        scrollToElement(hash);
    }
});

function scrollToElement(elementSelector, instance = 0) {
    const elements = document.querySelectorAll(elementSelector);
    if (elements.length > instance) {
        const targetElement = elements[instance];
        const targetPosition = targetElement.getBoundingClientRect().top + window.scrollY;

        const scrollAnimation = (startPosition, endPosition, duration) => {
            let startTime = null;

            const body = document.body;
            body.style.transition = 'filter 0.4s ease-out';
            body.style.filter = 'blur(3px)';  
            const animateScroll = (currentTime) => {
                if (!startTime) startTime = currentTime;
                const timeElapsed = currentTime - startTime;
                const progress = Math.min(timeElapsed / duration, 1);

                window.scrollTo(0, startPosition + (endPosition - startPosition) * progress);

                if (progress < 1) {
                    requestAnimationFrame(animateScroll);
                } else {
                    body.style.filter = 'none';
                }
            };

            requestAnimationFrame(animateScroll);
        };

        // Evita o scroll direto
        window.scrollTo(0, window.scrollY); 
        scrollAnimation(window.scrollY, targetPosition, 400);  
    }
}

const link1 = document.getElementById("link1");
const link2 = document.getElementById("link2");
const link3 = document.getElementById("link3");

link1.addEventListener('click', () => {
    scrollToElement('.header');
});

link2.addEventListener('click', () => {
    scrollToElement('.header', 1);
});

link3.addEventListener('click', () => {
    scrollToElement('.column');
});
